rootProject.name = "Adaptavi_Learning_Platform"

